#ifndef TEST_TRANZACTII
#define TEST_TRANZACTII



void test_creeaza_tranzactie();

void test_destroy_tranzactie();

void test_createEmpty();

void test_add();    



void test_adaugatranzactie();

void test_stergetranzactie();

void test_modificatranzactie();

void test_filtrutranzactie();

void test_sort();

#endif