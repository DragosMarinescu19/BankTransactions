#ifndef SERVICE_BANCA
#define SERVICE_BANCA

#include "repo_banca.h"


int adaugatranzactie(List *v, char *tip, char *descriere, int zi, float suma);


int stergetranzactie(List *v, char *tip, char *descriere);


int modificatranzactie(List *v, char *tip, char *descriere, char *tip_nou, char *descriere_noua, int zi, float suma);

List filtrutranzactie(List *v, char *tip_nou);

typedef int(*FunctieComparare)(Banca* b1, Banca* b2);

List sorttranzactii(List *v);

#endif