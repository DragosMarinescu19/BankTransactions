#ifndef VALIDATOR_BANCA
#define VALIDATOR_BANCA

typedef struct {
    int zi;
    float suma;
    char tip[30];
    char descriere[30];
} Banca;

// Declarație a funcției
int service_inserare(Banca tranzactii[], int lungime,int zi,float suma,char *tip,char *descriere);

char * valideaza_banca(int zi,float suma,char *tip,char *descriere);

void repo_inserare(Banca tranzactii[], int lungime);


void service_modifica(Banca tranzactii[],int zi,float suma,char *tip,char *descriere,int lungime);

void repo_modifica(Banca tranzactii[],int zi,float suma,char *tip,char *descriere,int lungime);

int service_sterge(Banca tranzactii[], int lungime,int zi);



#endif
