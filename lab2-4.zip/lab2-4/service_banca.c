#include "service_banca.h"
#include <string.h>

/*
 * Adauga Materia Prima la lista 'v'
 * param v: lista
 * param tip: tiple Materiei Prime
 * param descriere: descriereul Materiei Prime
 * param zi: zia de Materie Prima
 * return: 1 - daca s-a efectuat adaugarea
 *         0 - daca datele au fost invalide
 */
int adaugatranzactie(List *v, char *tip, char *descriere, int zi, float suma) {
    Banca b = creeaza_tranzactie(tip, descriere, zi, suma);
    if(valideaza_tranzactie(b)==0) {
        destroy_tranzactie(&b);
        return 0;
    }
    // se modifica zia daca se da o materie prima cu acelasi tip si descriere ce este in stoc.
    for(int i = 0; i< size(v); i++) {
        if(strcmp(get(v, i).tip, b.tip)==0 && strcmp(get(v, i).descriere, b.descriere)==0) {
            modificatranzactie(v,tip,descriere, tip, descriere, zi, suma);
            destroy_tranzactie(&b);
            return 1;
        }
    }
    add(v, b);
    return 1;
}

/*
 * Sterge materia prima in functie de tip si descriere
 * param v: lista
 * param tip: tiple Materiei Prime ce se sterge
 * param descriere: descriereul Materiei Prime ce se sterge
 * return: 1 - daca s-a sters din stoc
 *         0 - daca nu s-a sters nimic din stoc
 */
int stergetranzactie(List *v, char *tip, char *descriere) {
    int poz;
    for(int i = 0; i< size(v); i++) {
        if(strcmp(get(v, i).tip, tip)==0 && strcmp(get(v, i).descriere, descriere)==0) {
            poz = i;
            Banca b = delete(v, poz);
            destroy_tranzactie(&b);
            return 1;
        }
    }
    return 0;
}

/*
 * Modifica Materia Prima in finctie de tip si descriere
 * param v: lista
 * param tip: tiple Materiei Prime ce se modifica
 * param descriere: descriereul Materiei Prime ce se modifica
 * param tip_nou: tiple Materiei Prime noi
 * param descriere_nou: descriereul Materiei Prime noi
 * param zi: zia Materiei Prime noi
 * return: 1 - daca s-a modificat
 *         0 - daca nu s-a modificat
 */
int modificatranzactie(List *v, char *tip, char *descriere, char *tip_nou, char *descriere_nou, int zi,float suma) {
    Banca b= creeaza_tranzactie(tip_nou, descriere_nou, zi,suma);
    if(valideaza_tranzactie(b)==0) {
        destroy_tranzactie(&b);
        return 0;
    }
    int sters = stergetranzactie(v, tip, descriere);
    if(sters==0) {
        destroy_tranzactie(&b);
        return 0;
    } else {
        adaugatranzactie(v, tip_nou, descriere_nou, zi,suma);
        destroy_tranzactie(&b);
    }
    return 1;
}


List filtrutranzactie(List *v, char *tip_nou) {
    List listaFiltrata = createEmpty();
    for(int i = 0; i < v->length; i++) {
       Banca b = get(v, i);
        if(strcmp(b.tip,tip_nou)==0) {
            add(&listaFiltrata, creeaza_tranzactie(b.tip, b.descriere, b.zi, b.suma));
        }
    }
    return listaFiltrata;
}

int compararesuma(Banca* b1, Banca* b2) {
    return b1->suma > b2->suma;
}

int compararezi(Banca* b1, Banca* b2) {
    return b1->zi > b2->zi;
}


void sort(List* v, FunctieComparare compararesuma, FunctieComparare compararezi) {
    List listaSortata = *v;
    Banca temp;
    for(int i = 0; i < size(&listaSortata)-1; i++) {
        for(int j = i+1; j < size(&listaSortata); j++) {
            if(compararesuma(&listaSortata.elements[i], &listaSortata.elements[j])>0) {// le ordonez dupa suma
                temp = listaSortata.elements[i];
                listaSortata.elements[i] = listaSortata.elements[j];
                listaSortata.elements[j] = temp;
            }
            else if(compararesuma(&listaSortata.elements[i], &listaSortata.elements[j])==0) { // daca suma este dientica le ordonez dupa zi
                if(compararezi(&listaSortata.elements[i], &listaSortata.elements[j])) {
                    temp = listaSortata.elements[i];
                    listaSortata.elements[i] = listaSortata.elements[j];
                    listaSortata.elements[j] = temp;
                }
            }
        }
    }
}

/*
 * Sorteaza tranzactia in functie de suma si de zi
 * param v: lista
 * return: lista sortata
 */
List sorttranzactii(List *v) {
    List listaSortata = *v;
    sort(&listaSortata, compararesuma, compararezi);
    return listaSortata;
}