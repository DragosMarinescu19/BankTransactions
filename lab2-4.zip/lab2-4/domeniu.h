
#ifndef DOMENIU_H
#define DOMENIU_H

typedef struct {
    int zi;
    float suma;
    char *tip;
    char *descriere;
} Banca;

 Banca creeaza_tranzactie(char *tip, char *descriere, int zi, float suma);
 int valideaza_tranzactie(Banca b);
 void destroy_tranzactie(Banca *b);

 
#endif 
