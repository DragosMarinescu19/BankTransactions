#include <stdio.h>

#include "service_banca.h"
#include "test_tranzactii.h"
/*

Creati o aplicatie care permite gestiunea tranzactiilor unui cont bancar. 
O tranzactie are urmatoarele elemente: ziua (ziua din luna in care s-a efectuat tranzactia),
suma, tip (intrare/iesire), descriere.
Aplicatia permite:
a) adaugare de tranzactii
b) modificare tranzactie existenta
c) stergere  tranzactie existenta
d) Vizualizare tranzactii dupa un criteriu (tranzactii de un anumit tip, tranzactii cu suma mai mare/mai mica decat o suma data)
e) Vizualizare tranzactii ordonat dupa suma sau zi (crescator/descrescator)
*/

void testAll() {
    test_creeaza_tranzactie();

    test_destroy_tranzactie();

    test_createEmpty();

    test_add();

    test_adaugatranzactie();

    test_stergetranzactie();

    test_modificatranzactie();

    test_filtrutranzactie();

    test_sort();

}

// Functia ui de adaugare
void uiAdd(List *v) {
    char tip[30], descriere[30];
    int zi;
    float suma;

    printf("tip: ");
    scanf("%s", tip);
    printf("descriere: ");
    scanf("%s", descriere);
    printf("zi: ");
    scanf("%d", &zi);
    printf("Suma:");
    scanf("%f",&suma);
    int succes = adaugatranzactie(v, tip, descriere, zi, suma);
    if(succes)
        printf("Tranzactie adaugata cu succes!\n");
    else
        printf("Tranzactia nu este valida!\n");
}

// Functia ui de modificare
void uiModify(List *v) {
    char tip[30], tip_nou[30], descriere[30], descriere_nou[30];
    int zi;
    float suma;
    printf("De modificat\n");
    printf("tip: ");
    scanf("%s", tip);
    printf("descriere: ");
    scanf("%s", descriere);
    printf("tip nou: ");
    scanf("%s", tip_nou);
    printf("descriere nou: ");
    scanf("%s", descriere_nou);
    printf("zi: ");
    scanf("%d", &zi);
    printf("suma:");
    scanf("%f",&suma);
    int succes = modificatranzactie(v, tip, descriere, tip_nou, descriere_nou, zi, suma);
    if(succes)
        printf("Modificarea s-a efectuat cu succes!\n");
    else
        printf("Modificarea nu s-a efectuat! Date invalide!\n");
}

// Functia ui de stergere
void uiDelete(List *v) {
    char tip[30], descriere[30];
    printf("tipul tranzactiei de sters: ");
    scanf("%s", tip);
    printf("Descrierea tranzactiei de sters: ");
    scanf("%s", descriere);
    int succes = stergetranzactie(v, tip, descriere);
    if(succes)
        printf("tranzactia stearsa cu succes!\n");
    else
        printf("Nu exista tranzactie de acest fel!\n");
}

// Functia ui de afisare a tranzactiilor
void print(List *v) {
    if(v->length == 0)
        printf("Lista de tranzactii este goala!\n");
    else {
        for(int i = 0; i<size(v); i++) {
            Banca b= get(v, i);
            printf("Tip: %s | Descriere: %s | zi: %d | Suma: %f\n", b.tip, b.descriere, b.zi, b.suma);
        }
    }
}

// Functia ui de filtrare dupa tip
void uiFiltru(List *v) {
    char tip_nou[30];
    printf("Dati tipul ");
    scanf(" %s", tip_nou);
    List listaFiltrata = filtrutranzactie(v, tip_nou);
    print(&listaFiltrata);
}

// Functia ui de sortare
void uiSort(List *v) {
    List listaSortata = sorttranzactii(v);
    print(&listaSortata);
}

// meniu
void uiMenu() {
    printf("-- MENIU --\n");
    printf("1. Adaugare tranzactie (daca exista deja in stoc se actualizeaza zia\n");
    printf("2. Modificare tranzactie\n");
    printf("3. Stergere tranzactie\n");
    printf("4. Afisare tranzactii\n");
    printf("5. Afisare tranzactii dupa tip\n");
    printf("6. Afisare tranzactii sortate dupa zi\n");
    printf("0. Iesire din program.\n");
    printf("--\t--\t--\n");
}

// Functia run
void run() {
    List tranzactii = createEmpty();
    int ok = 1, option;
    while(ok) {
        uiMenu();
        printf("Optiune: ");
        scanf("%d", &option);
        switch (option) {
            case 1:
                printf("Adauga tranzactie\n");
                uiAdd(&tranzactii);
                printf("--\t--\t--\n");
                break;
            case 2:
                printf("Modificare tranzactie\n");
                uiModify(&tranzactii);
                printf("--\t--\t--\n");
                break;
            case 3:
                printf("Sterge tranzactie\n");
                uiDelete(&tranzactii);
                printf("--\t--\t--\n");
                break;
            case 4:
                print(&tranzactii);
                printf("--\t--\t--\n");
                break;
            case 5:
                printf("Filtrare tranzactie\n");
                uiFiltru(&tranzactii);
                printf("--\t--\t--\n");
                break;
            case 6:
                printf("Sortare tranzactii\n");
                uiSort(&tranzactii);
                printf("--\t--\t--\n");
                break;
            case 0:
                printf("Iesire din program.\n");
                printf("--\t--\t--\n");
                ok = 0;
                destroy(&tranzactii);
                break;
            default:
                printf("Optiunea nu este valida!\n");
                printf("--\t--\t--\n");
                break;
        }
    }
}

int main() {
    testAll();
    run();
    return 0;
}