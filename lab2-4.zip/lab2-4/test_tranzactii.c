#include "test_tranzactii.h"

#include "service_banca.h"
#include "repo_banca.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>

// teste DOMAIN
void test_creeaza_tranzactie() {
    Banca b = creeaza_tranzactie("intrare", "mall", 12,100);
    assert(strcmp(b.tip, "intrare")==0);
    assert(strcmp(b.descriere, "mall")==0);
    assert(b.zi==12);
    assert(b.suma==100);
    destroy_tranzactie(&b);
}

void test_destroy_tranzactie() {
    Banca b = creeaza_tranzactie("intrare", "mall", 12,100);
    destroy_tranzactie(&b);
    assert(b.tip == NULL);
    assert(b.descriere == NULL);
    assert(b.zi == -1);
}


void test_createEmpty() {
    List v = createEmpty();
    assert(v.length == 0);
    destroy(&v);
}

void test_add() {
    List lista = createEmpty();
    Banca b = creeaza_tranzactie("intrare", "mall", 12,100);
    assert(lista.length == 0);
    add(&lista, b);
    assert(lista.length == 1);
    destroy(&lista);
    assert(lista.length==0);
}




void test_adaugatranzactie() {
    List lista = createEmpty();
    Banca b = creeaza_tranzactie("intrare", "mall", 12,100);
    assert(adaugatranzactie(&lista, b.tip, b.descriere, b.zi, b.suma)==1);
    destroy_tranzactie(&b);
    assert(size(&lista)==1);
    Banca b2 = creeaza_tranzactie("intrare", "mall", 12,-100);
    assert(adaugatranzactie(&lista, b2.tip, b2.descriere, b2.zi, b2.suma)==0);
    destroy_tranzactie(&b2);
    assert(adaugatranzactie(&lista, "ex", "prod", 12,100)==1);
    assert(size(&lista)==2);
    destroy(&lista);
    assert(lista.length==0);
}

void test_stergetranzactie() {
    List lista = createEmpty();
    Banca b = creeaza_tranzactie("intrare", "mall", 12,100);
    stergetranzactie(&lista, b.tip, b.descriere);
    destroy_tranzactie(&b);
    assert(size(&lista)==0);
    destroy(&lista);
}

void test_modificatranzactie() {
    List lista = createEmpty();
    assert(adaugatranzactie(&lista, "intrare", "mall", 10,190)==1);
    assert(size(&lista)==1);
    assert(modificatranzactie(&lista, "intrare", "mall", "iesire", "mall", 20,200)==1);
    assert(lista.elements[0].zi==20);
    assert(modificatranzactie(&lista, "intrare", "mall", "iesire", "", -10,200)==0);
    assert(modificatranzactie(&lista, "iesre", "mall", "intrare", "descriere", 10,-100)==0);
    assert(lista.length==1);
    destroy(&lista);
    assert(lista.length==0);
}

void test_filtrutranzactie() {
    List lista = createEmpty();
    assert(adaugatranzactie(&lista, "intrare", "mall", 20,200));
    assert(adaugatranzactie(&lista, "altele", "mall", 19,210));
    assert(adaugatranzactie(&lista, "iesire", "mall", 30,220));
    List lista_filtrata = filtrutranzactie(&lista, "intrare");
    assert(size(&lista_filtrata)==1);
    destroy(&lista);
    assert(lista.length==0);
    destroy(&lista_filtrata);
}

void test_sort() {
    List  lista = createEmpty();
    assert(adaugatranzactie(&lista, "intrare", "mall", 10,220));
    assert(adaugatranzactie(&lista, "intrare", "mall", 23,100));
    assert(adaugatranzactie(&lista, "intrare", "mall", 30,200));
    assert(adaugatranzactie(&lista, "intrare", "mall", 20,230));
    assert(adaugatranzactie(&lista, "intrare", "mall", 1,230));
    assert(adaugatranzactie(&lista, "intrare", "mall", 20,700));
    List lista_sortata = sorttranzactii(&lista);
    /*printf("%d",size(&lista_sortata));
    assert(size(&lista_sortata)==6);
    assert(get(&lista_sortata, 0).suma==100);
    assert(get(&lista_sortata, 1).suma==200);
    assert(get(&lista_sortata, 3).zi==1);
    */
    destroy(&lista);
    assert(lista.length==0);
}