#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "validator_banca.h"

char *valideaza_banca(int zi,float suma,char *tip,char *descriere)
{
    //returnez stringule de erori concatenate 
    char *erori = (char *)malloc(100 * sizeof(char));
    if( zi<=0 || zi>=32)
        strcat(erori,"ziua nu este corecta\n");
    if(suma<0) 
        strcat(erori,"suma introdusa nu este corecta\n");
    if(strcmp(tip,"")==0)
        strcat(erori,"tipul nu este corect\n");
    if(strcmp(descriere,"")==0)
        strcat(erori,"descrierea nu este corecta\n");
    return erori;
    
}
