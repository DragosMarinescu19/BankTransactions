#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include "domeniu.h"

Banca creeaza_tranzactie(char *tip, char *descriere, int zi, float suma)
{
    Banca b;
    int nrc;
    b.zi=zi;
    b.suma=suma;
    b.tip=malloc( (strlen(tip)+1)*sizeof(char));
    strcpy(b.tip,tip);
    b.descriere=malloc((strlen(descriere)+1)*sizeof(char));
    strcpy(b.descriere,descriere);

    return b;

}

int valideaza_tranzactie(Banca b)
{
    if( b.zi<=0 || b.zi>=32)
        return 0;
    if(b.suma<0) 
        return 0;
    if(strcmp(b.tip,"")==0)
        return 0;
    if(strcmp(b.descriere,"")==0)
        return 0;
    return 1;
}

void destroy_tranzactie(Banca *b) {
//    b -> tip[0] = '\0';
//    b -> descriere[0] = '\0';
    free(b->tip);
    free(b->descriere);
    b ->zi = -1;
    b ->suma =-1;
    b->tip = NULL;
    b->descriere = NULL;

}